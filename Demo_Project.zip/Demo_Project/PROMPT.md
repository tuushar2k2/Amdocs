# Bill/Invoice Generator Web Application - Creation Prompt

Create a complete, professional Bill/Invoice Generator web application with the following specifications:

## Project Overview
A single-page web application for generating professional invoices/bills for businesses. The application should allow users to input company details, customer information, items, and generate printable/downloadable PDF invoices.

## Technology Stack
- **HTML5** - Structure
- **CSS3** - Styling (modern, responsive design)
- **Vanilla JavaScript** - Functionality (no frameworks required)
- **html2pdf.js** - PDF generation library (CDN: https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js)
- **localStorage** - For saving customer and tanker data

## File Structure
```
bill-generator/
├── index.html          (Main HTML structure)
├── styles.css          (All styling)
└── app.js             (All JavaScript functionality)
```

## Core Features

### 1. Company Management
- **Company Selection**: Dropdown to select between multiple companies
- **Company Details Display**: Show company name, tagline, address, city, phone, email, registration number
- **Company Information**: Each company should have:
  - Name
  - Tagline
  - Address
  - City
  - Phone
  - Email
  - Registration Number
  - GSTIN (optional)
  - PAN (optional)
  - Bank Details (Bank Name, Account No, IFSC, Branch) - optional

### 2. Invoice Details
- **Invoice Number**: Auto-generated format: `INV-YYMM-XXX` (e.g., INV-2601-123)
- **Invoice Date**: Date picker (defaults to today's date)

### 3. Customer Management
- **Customer Dropdown**: Select from saved customers or add new
- **Customer Fields**:
  - Name (required)
  - Address
  - GSTIN
  - Phone
- **Customer Actions**:
  - Save customer to localStorage
  - Delete customer
  - Auto-load customer details when selected
- **Data Persistence**: Customers saved in localStorage with key `billGenerator_customers`

### 4. Items Management
- **Dynamic Item Rows**: Add/remove multiple items
- **Item Fields** (per row):
  - Serial Number (auto-generated)
  - Date (date picker, defaults to today)
  - Chalan No. (text input)
  - Type (dropdown: Water Tanker, Sand, Gravel, Cement, Bricks, Other)
  - Tanker No. (text input with autocomplete from saved tankers)
  - Quantity (number input)
  - Rate (₹) (number input, decimal)
  - Amount (₹) (auto-calculated, readonly)
  - Remove button (×)
- **Tanker Number Management**:
  - Auto-save tanker numbers when entered
  - Display saved tanker numbers as tags
  - Delete tanker numbers
  - Saved in localStorage with key `billGenerator_tankers`

### 5. Tax & Charges
- **CGST Rate (%)**: Number input (default: 9)
- **SGST Rate (%)**: Number input (default: 9)
- **IGST Rate (%)**: Number input (default: 0, for inter-state)
- **Discount (%)**: Number input (default: 0)
- **Transport Charges (₹)**: Number input (default: 0)

### 6. Calculations
- **Auto-calculate** when any value changes:
  - Item Total = Quantity × Rate
  - Subtotal = Sum of all item totals
  - Discount Amount = (Subtotal × Discount Rate) / 100
  - Taxable Amount = Subtotal - Discount Amount
  - CGST Amount = (Taxable Amount × CGST Rate) / 100
  - SGST Amount = (Taxable Amount × SGST Rate) / 100
  - IGST Amount = (Taxable Amount × IGST Rate) / 100
  - Grand Total = Taxable Amount + CGST + SGST + IGST + Transport Charges
- **Amount in Words**: Convert grand total to words (Indian numbering system: Lakh, Crore)

### 7. Additional Fields
- **Notes/Terms**: Textarea for payment terms, delivery notes, etc.

### 8. Bill Preview
- **Modal Popup**: Display generated bill in a modal
- **Bill Preview Contains**:
  - Company header (company name in sky blue color)
  - Invoice title
  - Customer details (Bill To section)
  - Invoice number and date
  - Items table with all columns
  - Totals section (Subtotal, Discount, CGST, SGST, IGST, Transport, Grand Total)
  - Amount in words
  - Bank details (if provided)
  - Terms & Conditions
  - Signature section

### 9. PDF Generation
- **Print Button**: Generate and download PDF
- **PDF Requirements**:
  - A4 size (210mm × 297mm)
  - High quality (scale: 3, PNG format)
  - Clear, readable text (antialiased fonts)
  - Proper margins and padding
  - All content visible (no cropping)
  - Filename format: `{InvoiceNo}_{CustomerName}.pdf`
- **Download PDF Button**: Alternative method to download PDF

### 10. Form Management
- **Clear All Button**: Reset all fields with confirmation
- **Generate Bill Button**: Create bill preview in modal

## UI/UX Requirements

### Design
- **Modern, Clean Interface**: Professional business application look
- **Color Scheme**: 
  - Primary: Sky blue (#0ea5e9) for company name
  - Secondary: Professional grays and whites
  - Success: Green for download buttons
  - Danger: Red for delete/remove actions
- **Typography**: Arial or similar sans-serif font
- **Responsive**: Works on desktop (tablet/mobile optional)

### Layout
- **Header**: Application title "Bill / Invoice Generator"
- **Form Section**: 
  - Company selection at top
  - Company info display
  - Invoice details (2 columns)
  - Customer section
  - Items section with add button
  - Tax and charges section (3 columns)
  - Totals summary panel
  - Action buttons
- **Modal**: 
  - Centered overlay
  - Scrollable content
  - Close button
  - Print and Download buttons in footer

### Styling Details
- Form inputs: Clean borders, proper spacing
- Buttons: Rounded corners, hover effects
- Table: Bordered, clear headers, alternating row colors optional
- Modal: Backdrop blur, centered, max-width constraint
- Bill preview: Print-friendly styling, proper spacing

## Functionality Details

### Number to Words Conversion
Implement Indian numbering system:
- Units: One, Two, Three... Nineteen
- Tens: Twenty, Thirty, Forty... Ninety
- Hundreds: Hundred
- Thousands: Thousand
- Lakhs: Lakh (100,000)
- Crores: Crore (10,000,000)
- Format: "X Lakh Y Thousand Z Hundred Rupees Only"

### Data Validation
- Customer name required to save customer
- Invoice number auto-generated
- Date defaults to today
- Quantity and rates default to 0
- Prevent negative values where applicable

### Error Handling
- Show alerts for missing required fields
- Confirm before delete actions
- Handle PDF generation errors gracefully
- Show loading indicator during PDF generation

### User Experience
- Toast notifications for success messages
- Loading overlay during PDF generation
- Smooth transitions
- Keyboard shortcuts (Escape to close modal)
- Click outside modal to close

## Technical Implementation Notes

### localStorage Structure
```javascript
// Customers
billGenerator_customers: [
  {
    name: "Customer Name",
    address: "Address",
    gstin: "GSTIN",
    phone: "Phone"
  }
]

// Tankers
billGenerator_tankers: ["TANKER1", "TANKER2", ...]
```

### Company Data Structure
```javascript
COMPANIES = {
  companyKey: {
    name: "Company Name",
    tagline: "Tagline",
    address: "Address",
    city: "City - PIN",
    phone: "Phone",
    email: "Email",
    regNo: "Registration Number",
    gstin: "",
    pan: "",
    bankName: "",
    accountNo: "",
    ifsc: "",
    branch: ""
  }
}
```

### PDF Generation Settings
- Use html2pdf.js library
- Scale: 3 for high quality
- Format: PNG (not JPEG) for text clarity
- A4 format: 210mm × 297mm
- No compression for quality
- Font smoothing enabled
- Proper width: 794px (A4 width at 96 DPI)
- Padding: 15px
- Table layout: Fixed to prevent overflow

## Example Company Data
```javascript
{
  nakhate: {
    name: 'NAKHATE ENTERPRISES',
    tagline: 'WATER TANKER & BUILDING MATERIAL SUPPLIERS',
    address: 'Vitthal Mandir, Nakhate Wasti, Rahatni',
    city: 'Pune - 411017',
    phone: '9552487700',
    email: 'kuldeepnakhate@gmail.com',
    regNo: 'PIMPRI / II / 60661'
  }
}
```

## Deliverables
1. **index.html**: Complete HTML structure with all form elements, modal, and templates
2. **styles.css**: Comprehensive styling for all components, responsive design, print styles
3. **app.js**: All JavaScript functionality including:
   - Company management
   - Customer CRUD operations
   - Tanker number management
   - Item management
   - Calculations
   - Number to words conversion
   - Bill generation
   - PDF generation
   - Form clearing
   - localStorage operations

## Testing Checklist
- [ ] Company selection works
- [ ] Customer save/load/delete works
- [ ] Tanker numbers save and display
- [ ] Items can be added/removed
- [ ] Calculations are accurate
- [ ] Bill preview displays correctly
- [ ] PDF downloads with all content visible
- [ ] PDF is A4 size
- [ ] Text in PDF is clear and readable
- [ ] Amount in words is correct
- [ ] Form clearing works
- [ ] Data persists in localStorage

## Additional Notes
- Use semantic HTML5 elements
- Follow accessibility best practices
- Ensure cross-browser compatibility
- Code should be well-commented
- Use consistent naming conventions
- Handle edge cases (empty fields, zero values, etc.)

---

**This prompt should enable recreation of a fully functional Bill/Invoice Generator web application matching the current implementation.**
