// Bill Generator Application

// Company Details
const COMPANIES = {
    nakhate: {
        name: 'NAKHATE ENTERPRISES',
        tagline: 'WATER TANKER & BUILDING MATERIAL SUPPLIERS',
        address: 'Vitthal Mandir, Nakhate Wasti, Rahatni',
        city: 'Pune - 411017',
        phone: '9552487700',
        email: 'kuldeepnakhate@gmail.com',
        regNo: 'PIMPRI / II / 60661',
        gstin: '',
        pan: '',
        bankName: '',
        accountNo: '',
        ifsc: '',
        branch: ''
    },
    dattguru: {
        name: 'DATTGURU ENTERPRISES',
        tagline: 'WATER TANKER & BUILDING MATERIAL SUPPLIERS',
        address: 'Vitthal Mandir, Nakhate Wasti, Rahatni',
        city: 'Pune - 411017',
        phone: '9552487700',
        email: 'kuldeepnakhate@gmail.com',
        regNo: 'PIMPRI / II / 60661',
        gstin: '',
        pan: '',
        bankName: '',
        accountNo: '',
        ifsc: '',
        branch: ''
    }
};

let itemCount = 0;

// Date format DD/MM/YYYY
function formatDateDDMMYYYY(date) {
    if (!(date instanceof Date) || isNaN(date)) return '';
    const d = date.getDate().toString().padStart(2, '0');
    const m = (date.getMonth() + 1).toString().padStart(2, '0');
    const y = date.getFullYear();
    return `${d}/${m}/${y}`;
}

function parseDateDDMMYYYY(str) {
    if (!str || typeof str !== 'string') return null;
    const s = str.trim();
    // DD/MM/YYYY
    const slashParts = s.split('/');
    if (slashParts.length === 3) {
        const day = parseInt(slashParts[0], 10);
        const month = parseInt(slashParts[1], 10) - 1;
        const year = parseInt(slashParts[2], 10);
        if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
            const d = new Date(year, month, day);
            if (d.getFullYear() === year && d.getMonth() === month && d.getDate() === day)
                return d;
        }
    }
    // YYYY-MM-DD (e.g. from old type="date")
    const iso = new Date(s);
    if (!isNaN(iso.getTime())) return iso;
    return null;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Invoice Date with calendar, display in DD/MM/YYYY
    const invoiceDateEl = document.getElementById('invoiceDate');
    if (invoiceDateEl && typeof flatpickr !== 'undefined') {
        flatpickr(invoiceDateEl, {
            dateFormat: 'd/m/Y',
            defaultDate: 'today',
            allowInput: true,
            disableMobile: true
        });
    }

    // Generate invoice number
    generateInvoiceNumber();
    
    // Update company details
    updateCompanyDetails();
    
    // Load saved customers
    loadCustomerDropdown();
    
    // Load saved tanker numbers
    loadTankerDropdown();
    
    // Add first item
    addItem();
});

// ==================== CUSTOMER MANAGEMENT ====================

// Get customers from localStorage
function getCustomers() {
    const customers = localStorage.getItem('billGenerator_customers');
    return customers ? JSON.parse(customers) : [];
}

// Save customers to localStorage
function saveCustomers(customers) {
    localStorage.setItem('billGenerator_customers', JSON.stringify(customers));
}

// Load customer dropdown
function loadCustomerDropdown() {
    const customers = getCustomers();
    const select = document.getElementById('customerSelect');
    
    // Clear existing options except first
    select.innerHTML = '<option value="">-- Select Customer or Add New --</option>';
    
    // Add customers to dropdown
    customers.forEach((customer, index) => {
        const option = document.createElement('option');
        option.value = index;
        option.textContent = customer.name + (customer.phone ? ` (${customer.phone})` : '');
        select.appendChild(option);
    });
}

// Load selected customer details
function loadCustomer() {
    const select = document.getElementById('customerSelect');
    const selectedIndex = select.value;
    
    if (selectedIndex === '') {
        // Clear fields if "Add New" is selected
        document.getElementById('customerName').value = '';
        document.getElementById('customerAddress').value = '';
        document.getElementById('customerGST').value = '';
        document.getElementById('customerPhone').value = '';
        document.getElementById('customerRate').value = '';
        return;
    }
    
    const customers = getCustomers();
    const customer = customers[selectedIndex];
    
    if (customer) {
        document.getElementById('customerName').value = customer.name || '';
        document.getElementById('customerAddress').value = customer.address || '';
        document.getElementById('customerGST').value = customer.gstin || '';
        document.getElementById('customerPhone').value = customer.phone || '';
        document.getElementById('customerRate').value = customer.rate != null && customer.rate !== '' ? customer.rate : '';
        applyCustomerRateToItems();
    }
}

// Apply customer rate to all item rows
function applyCustomerRateToItems() {
    const rateInput = document.getElementById('customerRate');
    const rate = rateInput && rateInput.value !== '' ? parseFloat(rateInput.value) : null;
    if (rate === null || isNaN(rate)) return;
    document.querySelectorAll('.item-row').forEach(row => {
        const itemPriceInput = row.querySelector('.item-price');
        if (itemPriceInput) itemPriceInput.value = rate;
    });
    calculateTotals();
}

// Save current customer
function saveCustomer() {
    const name = document.getElementById('customerName').value.trim();
    const address = document.getElementById('customerAddress').value.trim();
    const gstin = document.getElementById('customerGST').value.trim();
    const phone = document.getElementById('customerPhone').value.trim();
    const rateVal = document.getElementById('customerRate').value.trim();
    const rate = rateVal === '' ? '' : (parseFloat(rateVal) || 0);
    
    if (!name) {
        alert('Please enter customer name to save.');
        return;
    }
    
    const customers = getCustomers();
    
    // Check if customer already exists (by name)
    const existingIndex = customers.findIndex(c => c.name.toLowerCase() === name.toLowerCase());
    
    const customerData = { name, address, gstin, phone, rate };
    
    if (existingIndex >= 0) {
        // Update existing customer
        if (confirm(`Customer "${name}" already exists. Do you want to update the details?`)) {
            customers[existingIndex] = customerData;
            saveCustomers(customers);
            loadCustomerDropdown();
            document.getElementById('customerSelect').value = existingIndex;
            alert('Customer updated successfully!');
        }
    } else {
        // Add new customer
        customers.push(customerData);
        saveCustomers(customers);
        loadCustomerDropdown();
        document.getElementById('customerSelect').value = customers.length - 1;
        alert('Customer saved successfully!');
    }
}

// Delete selected customer
function deleteCustomer() {
    const select = document.getElementById('customerSelect');
    const selectedIndex = select.value;
    
    if (selectedIndex === '') {
        alert('Please select a customer to delete.');
        return;
    }
    
    const customers = getCustomers();
    const customer = customers[selectedIndex];
    
    if (confirm(`Are you sure you want to delete customer "${customer.name}"?`)) {
        customers.splice(selectedIndex, 1);
        saveCustomers(customers);
        loadCustomerDropdown();
        
        // Clear form fields
        document.getElementById('customerName').value = '';
        document.getElementById('customerAddress').value = '';
        document.getElementById('customerGST').value = '';
        document.getElementById('customerPhone').value = '';
        document.getElementById('customerRate').value = '';
        
        alert('Customer deleted successfully!');
    }
}

// ==================== END CUSTOMER MANAGEMENT ====================

// ==================== TANKER NUMBER MANAGEMENT ====================

// Get tanker numbers from localStorage
function getTankerNumbers() {
    const tankers = localStorage.getItem('billGenerator_tankers');
    return tankers ? JSON.parse(tankers) : [];
}

// Save tanker numbers to localStorage
function saveTankerNumbers(tankers) {
    localStorage.setItem('billGenerator_tankers', JSON.stringify(tankers));
}

// Load tanker numbers into datalist and tags
function loadTankerDropdown() {
    const tankers = getTankerNumbers();
    const datalist = document.getElementById('tankerList');
    const tagsContainer = document.getElementById('tankerTags');
    
    // Clear existing options
    datalist.innerHTML = '';
    
    // Add tanker numbers to datalist
    tankers.forEach(tanker => {
        const option = document.createElement('option');
        option.value = tanker;
        datalist.appendChild(option);
    });
    
    // Update tags display
    if (tagsContainer) {
        if (tankers.length === 0) {
            tagsContainer.innerHTML = '<span style="color:#999; font-size:0.8rem;">No tankers saved yet. Enter a tanker number to save it.</span>';
        } else {
            tagsContainer.innerHTML = tankers.map(tanker => `
                <span class="tanker-tag">
                    ${tanker}
                    <span class="delete-tag" onclick="deleteTankerNumber('${tanker}')" title="Delete">×</span>
                </span>
            `).join('');
        }
    }
}

// Save tanker number when entered
function saveTankerNumber(tankerNo) {
    if (!tankerNo || tankerNo.trim() === '') return;
    
    const tankerNumber = tankerNo.trim().toUpperCase();
    const tankers = getTankerNumbers();
    
    // Check if already exists
    if (!tankers.includes(tankerNumber)) {
        tankers.push(tankerNumber);
        tankers.sort(); // Sort alphabetically
        saveTankerNumbers(tankers);
        loadTankerDropdown();
    }
}

// Delete a tanker number
function deleteTankerNumber(tankerNo) {
    if (!confirm(`Delete tanker "${tankerNo}"?`)) return;
    
    const tankers = getTankerNumbers();
    const index = tankers.indexOf(tankerNo.toUpperCase());
    if (index > -1) {
        tankers.splice(index, 1);
        saveTankerNumbers(tankers);
        loadTankerDropdown();
    }
}

// ==================== END TANKER NUMBER MANAGEMENT ====================

// Invoice number: auto-incrementing sequence 1 to 1000000000000000 (persisted in localStorage)
const INVOICE_SEQUENCE_KEY = 'billGenerator_invoiceSequence';
const INVOICE_SEQUENCE_MAX = 1000000000000000;

function getNextInvoiceNumber() {
    let seq = parseInt(localStorage.getItem(INVOICE_SEQUENCE_KEY) || '0', 10);
    seq += 1;
    if (seq > INVOICE_SEQUENCE_MAX) seq = 1;
    localStorage.setItem(INVOICE_SEQUENCE_KEY, String(seq));
    return String(seq);
}

function generateInvoiceNumber() {
    document.getElementById('invoiceNo').value = getNextInvoiceNumber();
}

// Update Company Details Display
function updateCompanyDetails() {
    const companyKey = document.getElementById('companySelect').value;
    const company = COMPANIES[companyKey];
    
    const companyInfoDiv = document.getElementById('companyInfo');
    companyInfoDiv.innerHTML = `
        <h4>${company.name}</h4>
        <p><em>${company.tagline}</em></p>
        <p><strong>Office:</strong> ${company.address}, ${company.city}</p>
        <p><strong>Mobile No.:</strong> ${company.phone} | <strong>Email:</strong> ${company.email}</p>
        <p><strong>Reg No:</strong> ${company.regNo}</p>
    `;
}

// Add Item
function addItem() {
    itemCount++;
    const template = document.getElementById('itemTemplate');
    const clone = template.content.cloneNode(true);
    
    const itemRow = clone.querySelector('.item-row');
    itemRow.dataset.itemIndex = itemCount;
    
    // Set serial number
    clone.querySelector('.item-srno').value = itemCount;
    
    document.getElementById('itemsList').appendChild(clone);
    
    // Item date: calendar picker with DD/MM/YYYY
    const newRow = document.getElementById('itemsList').querySelector('.item-row:last-child');
    const newDateInput = newRow.querySelector('.item-date-value');
    if (newDateInput && typeof flatpickr !== 'undefined') {
        flatpickr(newDateInput, {
            dateFormat: 'd/m/Y',
            defaultDate: 'today',
            allowInput: true,
            disableMobile: true
        });
    }
    
    // Populate Rate from customer Rate field
    const customerRateInput = document.getElementById('customerRate');
    if (customerRateInput && customerRateInput.value !== '' && newRow) {
        const priceInput = newRow.querySelector('.item-price');
        if (priceInput) priceInput.value = customerRateInput.value;
    }
    
    // Update all serial numbers
    updateSerialNumbers();
    calculateTotals();
}

// Update Serial Numbers
function updateSerialNumbers() {
    document.querySelectorAll('.item-row').forEach((row, index) => {
        row.querySelector('.item-srno').value = index + 1;
    });
}

// Remove Item
function removeItem(btn) {
    const itemRow = btn.closest('.item-row');
    const dateInput = itemRow.querySelector('.item-date-value');
    if (dateInput && dateInput._flatpickr) {
        dateInput._flatpickr.destroy();
    }
    itemRow.remove();
    updateSerialNumbers();
    calculateTotals();
}

// Update Qty from Chalan No.: Qty = number of commas + 1 (e.g. "5,3,8,9,1" has 4 commas → Qty = 5)
function updateQtyFromChalan(chalanInput) {
    const row = chalanInput.closest('.item-row');
    if (!row) return;
    const value = (chalanInput.value || '').trim();
    const commaCount = (value.match(/,/g) || []).length;
    const qty = value === '' ? 0 : commaCount + 1;
    const qtyInput = row.querySelector('.item-quantity');
    if (qtyInput) {
        qtyInput.value = qty;
        qtyInput.min = 0;
        calculateTotals();
    }
}

// Calculate Totals
function calculateTotals() {
    let subtotal = 0;
    
    // Calculate each item total
    document.querySelectorAll('.item-row').forEach(row => {
        const qty = parseFloat(row.querySelector('.item-quantity').value) || 0;
        const price = parseFloat(row.querySelector('.item-price').value) || 0;
        const itemTotal = qty * price;
        row.querySelector('.item-total').value = itemTotal.toFixed(2);
        subtotal += itemTotal;
    });
    
    // Get rates
    const discountRate = parseFloat(document.getElementById('discount').value) || 0;
    const cgstRate = parseFloat(document.getElementById('cgstRate').value) || 0;
    const sgstRate = parseFloat(document.getElementById('sgstRate').value) || 0;
    const igstRate = parseFloat(document.getElementById('igstRate').value) || 0;
    const transportCharges = parseFloat(document.getElementById('transportCharges').value) || 0;
    
    // Calculate amounts
    const discountAmount = (subtotal * discountRate) / 100;
    const taxableAmount = subtotal - discountAmount;
    const cgstAmount = (taxableAmount * cgstRate) / 100;
    const sgstAmount = (taxableAmount * sgstRate) / 100;
    const igstAmount = (taxableAmount * igstRate) / 100;
    // Grand Total excludes CGST and SGST (those lines are not shown on the bill)
    const grandTotal = taxableAmount + igstAmount + transportCharges;
    
    // Update display (Discount, CGST, SGST, IGST, Transport rows removed from page)
    const subtotalEl = document.getElementById('subtotal');
    const grandTotalEl = document.getElementById('grandTotal');
    const amountInWordsEl = document.getElementById('amountInWords');
    if (subtotalEl) subtotalEl.textContent = `₹ ${subtotal.toFixed(2)}`;
    if (grandTotalEl) grandTotalEl.textContent = `₹ ${grandTotal.toFixed(2)}`;
    if (amountInWordsEl) amountInWordsEl.textContent = numberToWords(Math.round(grandTotal)) + ' Rupees Only';
    
    return {
        subtotal,
        discountAmount,
        taxableAmount,
        cgstAmount,
        sgstAmount,
        igstAmount,
        transportCharges,
        grandTotal
    };
}

// Validate all bill fields before generating - returns { valid: boolean, errors: string[] }
function validateBillForm() {
    const errors = [];
    
    // Company
    const companyKey = document.getElementById('companySelect').value;
    if (!companyKey || companyKey.trim() === '') {
        errors.push('Select Company');
    }
    
    // Invoice details
    const invoiceNo = document.getElementById('invoiceNo').value;
    if (!invoiceNo || invoiceNo.trim() === '') {
        errors.push('Invoice No');
    }
    
    const invoiceDate = document.getElementById('invoiceDate').value;
    if (!invoiceDate || invoiceDate.trim() === '') {
        errors.push('Invoice Date');
    } else if (!parseDateDDMMYYYY(invoiceDate)) {
        errors.push('Invoice Date (use DD/MM/YYYY)');
    }
    
    // Customer details
    const customerName = document.getElementById('customerName').value;
    if (!customerName || customerName.trim() === '') {
        errors.push('Customer/Company Name');
    }
    
    const customerAddress = document.getElementById('customerAddress').value;
    if (!customerAddress || customerAddress.trim() === '') {
        errors.push('Customer Address');
    }
    
    const customerPhone = document.getElementById('customerPhone').value;
    if (!customerPhone || customerPhone.trim() === '') {
        errors.push('Customer Phone');
    }
    
    // Items - validate each row
    const itemRows = document.querySelectorAll('.item-row');
    if (itemRows.length === 0) {
        errors.push('At least one item row (add an item)');
    }
    
    itemRows.forEach((row, index) => {
        const rowNum = index + 1;
        const itemDate = row.querySelector('.item-date-value').value;
        if (!itemDate || itemDate.trim() === '') {
            errors.push(`Item ${rowNum}: Date`);
        } else if (!parseDateDDMMYYYY(itemDate)) {
            errors.push(`Item ${rowNum}: Date (use DD/MM/YYYY)`);
        }
        
        const chalanNo = row.querySelector('.item-chalan-no').value;
        if (!chalanNo || chalanNo.trim() === '') {
            errors.push(`Item ${rowNum}: Chalan No`);
        }
        
        const type = row.querySelector('.item-type-value').value;
        if (!type || type.trim() === '') {
            errors.push(`Item ${rowNum}: Type`);
        }
        
        const tankerNo = row.querySelector('.item-tanker-no').value;
        if (!tankerNo || tankerNo.trim() === '') {
            errors.push(`Item ${rowNum}: Tanker No`);
        }
        
        const qty = row.querySelector('.item-quantity').value;
        if (qty === '' || qty === null || parseFloat(qty) <= 0) {
            errors.push(`Item ${rowNum}: Quantity`);
        }
        
        const price = row.querySelector('.item-price').value;
        if (price === '' || price === null || parseFloat(price) < 0) {
            errors.push(`Item ${rowNum}: Rate (₹)`);
        }
    });
    
    return {
        valid: errors.length === 0,
        errors: errors
    };
}

// Generate Bill Preview
function generateBill() {
    // Validate all fields before generating
    const validation = validateBillForm();
    if (!validation.valid) {
        const message = 'Please fill in all required fields before generating the bill.\n\nBlank or invalid fields:\n• ' + validation.errors.join('\n• ');
        alert(message);
        return;
    }
    
    const companyKey = document.getElementById('companySelect').value;
    const company = COMPANIES[companyKey];
    
    const invoiceNo = document.getElementById('invoiceNo').value;
    const invoiceDate = document.getElementById('invoiceDate').value;
    const customerName = document.getElementById('customerName').value || 'Cash Customer';
    const customerAddress = document.getElementById('customerAddress').value || '-';
    const customerGST = document.getElementById('customerGST').value || '-';
    const customerPhone = document.getElementById('customerPhone').value || '-';
    const notes = document.getElementById('notes').value || 'Thank you for your business!';
    
    const cgstRate = parseFloat(document.getElementById('cgstRate').value) || 0;
    const sgstRate = parseFloat(document.getElementById('sgstRate').value) || 0;
    const igstRate = parseFloat(document.getElementById('igstRate').value) || 0;
    
    // Get items
    const items = [];
    document.querySelectorAll('.item-row').forEach((row, index) => {
        const srno = row.querySelector('.item-srno').value;
        const itemDate = row.querySelector('.item-date-value').value;
        const chalanNo = row.querySelector('.item-chalan-no').value;
        const type = row.querySelector('.item-type-value').value;
        const tankerNo = row.querySelector('.item-tanker-no').value;
        const qty = row.querySelector('.item-quantity').value;
        const price = row.querySelector('.item-price').value;
        const total = row.querySelector('.item-total').value;
        
        // Format date for display (DD/MM/YYYY)
        let formattedItemDate = '-';
        const parsedItemDate = parseDateDDMMYYYY(itemDate);
        if (parsedItemDate) {
            formattedItemDate = formatDateDDMMYYYY(parsedItemDate);
        }
        
        items.push({
            sno: index + 1,
            date: formattedItemDate,
            chalanNo: chalanNo || '-',
            type: type || '-',
            tankerNo: tankerNo || '-',
            qty,
            price,
            total
        });
    });
    
    // Calculate totals
    const totals = calculateTotals();
    
    // Trip Count = sum of all item Qty
    const tripCount = items.reduce((sum, it) => sum + (parseFloat(it.qty) || 0), 0);
    
    // Format date (DD/MM/YYYY)
    const parsedInvoiceDate = parseDateDDMMYYYY(invoiceDate);
    const formattedDate = parsedInvoiceDate ? formatDateDDMMYYYY(parsedInvoiceDate) : invoiceDate || '-';
    
    // Generate bill HTML
    const billHTML = `
        <div class="bill-header">
            <h2>${company.name}</h2>
            <p class="tagline">${company.tagline}</p>
            <p><strong>Office:</strong> ${company.address}, ${company.city}</p>
            <p><strong>Mobile No.:</strong> ${company.phone} | <strong>Email:</strong> ${company.email}</p>
            <p><strong>Reg No:</strong> ${company.regNo}</p>
        </div>
        
        <div class="bill-title">INVOICE</div>
        
        <div class="bill-info">
            <div class="bill-info-left">
                <p class="bill-info-row"><strong>Customer Name:</strong> <span>${customerName}</span></p>
                <p class="bill-info-row"><strong>Address:</strong> <span class="bill-address-value">${customerAddress}</span></p>
            </div>
            <div class="bill-info-right">
                <p><strong>Invoice No:</strong> ${invoiceNo}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
            </div>
        </div>
        
        <table class="bill-table">
            <thead>
                <tr>
                    <th style="width:5%">Sr. No.</th>
                    <th style="width:12%">Date</th>
                    <th style="width:14%">Chalan No.</th>
                    <th style="width:8%">Type</th>
                    <th style="width:15%">Tanker No.</th>
                    <th style="width:8%">Qty</th>
                    <th style="width:14%">Rate (₹)</th>
                    <th style="width:18%">Amount (₹)</th>
                </tr>
            </thead>
            <tbody>
                ${items.map(item => `
                    <tr>
                        <td class="text-center">${item.sno}</td>
                        <td class="text-center">${item.date}</td>
                        <td class="text-center">${item.chalanNo}</td>
                        <td class="text-center">${item.type}</td>
                        <td class="text-center">${item.tankerNo}</td>
                        <td class="text-center">${item.qty}</td>
                        <td class="text-right amount-cell">${parseFloat(item.price).toFixed(2)}</td>
                        <td class="text-right amount-cell">${parseFloat(item.total).toFixed(2)}</td>
                    </tr>
                `).join('')}
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="7" class="text-right">Subtotal:</td>
                    <td class="text-right amount-cell">${totals.subtotal.toFixed(2)}</td>
                </tr>
                ${totals.discountAmount > 0 ? `
                <tr>
                    <td colspan="7" class="text-right">Discount (${document.getElementById('discount').value}%):</td>
                    <td class="text-right amount-cell">- ${totals.discountAmount.toFixed(2)}</td>
                </tr>
                ` : ''}
                ${igstRate > 0 ? `
                <tr>
                    <td colspan="7" class="text-right">IGST (${igstRate}%):</td>
                    <td class="text-right amount-cell">${totals.igstAmount.toFixed(2)}</td>
                </tr>
                ` : ''}
                ${totals.transportCharges > 0 ? `
                <tr>
                    <td colspan="7" class="text-right">Transport Charges:</td>
                    <td class="text-right amount-cell">${totals.transportCharges.toFixed(2)}</td>
                </tr>
                ` : ''}
                <tr class="grand-total-row">
                    <td colspan="5" class="text-right"><strong>Total Trip Count</strong></td>
                    <td class="text-right"><strong>${tripCount}</strong></td>
                    <td class="text-right"><strong>Grand Total:</strong></td>
                    <td class="text-right amount-cell"><strong>₹ ${totals.grandTotal.toFixed(2)}</strong></td>
                </tr>
            </tfoot>
        </table>
        
        <div class="amount-words">
            <strong>Amount in Words:</strong> ${numberToWords(Math.round(totals.grandTotal))} Rupees Only
        </div>
        
        ${company.bankName ? `
        <div class="bill-footer">
            <div class="bill-footer-left">
                <p><strong>Bank Details:</strong></p>
                <p>Bank: ${company.bankName}</p>
                <p>A/C No: ${company.accountNo}</p>
                <p>IFSC: ${company.ifsc}</p>
                <p>Branch: ${company.branch}</p>
            </div>
        </div>
        ` : ''}
        
        <div class="bill-footer-bottom">
            <div class="bill-footer-bottom-left">
                <p class="bill-payment-terms">**Payment should be done within 30 days after date of issue of bill.</p>
                <div class="bill-received-by">
                    <p><strong>Received By :</strong></p>
                    <p><strong>Date :</strong></p>
                </div>
            </div>
            <div class="bill-footer-bottom-divider"></div>
            <div class="bill-footer-bottom-right">
                <p><strong>For ${company.name}</strong></p>
                <p><strong>Proprietor Sign:</strong></p>
            </div>
        </div>
    `;
    
    document.getElementById('billContainer').innerHTML = billHTML;
    
    // Show modal popup
    openBillModal();
    
    // Show success message
    showToast('Bill generated successfully!', 'success');
}

// Open Bill Modal
function openBillModal() {
    const modal = document.getElementById('billModal');
    if (modal) {
        modal.style.display = 'flex';
        // Prevent body scroll when modal is open
        document.body.style.overflow = 'hidden';
    }
}

// Close Bill Modal
function closeBillModal() {
    const modal = document.getElementById('billModal');
    if (modal) {
        modal.style.display = 'none';
        // Restore body scroll
        document.body.style.overflow = '';
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('billModal');
    if (modal && event.target === modal) {
        closeBillModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeBillModal();
    }
});

// Print Bill - Downloads PDF matching exact preview
function printBill() {
    const billContainer = document.getElementById('billContainer');
    
    // Check if bill is generated, if not generate it first
    if (billContainer.querySelector('.empty-preview') || !billContainer.querySelector('.bill-header')) {
        // Generate bill first
        generateBill();
        // Wait for bill to be generated and rendered
        setTimeout(() => {
            printBill();
        }, 500);
        return;
    }
    
    // Verify bill has content
    const billHTML = billContainer.innerHTML.trim();
    if (!billHTML || billHTML.length < 100) {
        alert('Bill content is empty. Please generate the bill first.');
        return;
    }
    
    // Get invoice number and customer name for filename
    const invoiceNo = document.getElementById('invoiceNo').value || 'Invoice';
    const customerName = document.getElementById('customerName').value || 'Customer';
    const fileName = `${invoiceNo}_${customerName.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
    
    // Store original modal state
    const modal = document.getElementById('billModal');
    const originalModalDisplay = modal ? modal.style.display : 'none';
    
    // Ensure modal is visible so html2canvas can capture the content
    if (modal) {
        modal.style.display = 'flex';
    }
    
    // Show loading first
    const loadingOverlay = document.createElement('div');
    loadingOverlay.id = 'printLoading';
    loadingOverlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:99999;';
    loadingOverlay.innerHTML = '<div style="background:white;padding:30px 50px;border-radius:10px;font-size:18px;">Generating PDF... Please wait</div>';
    document.body.appendChild(loadingOverlay);
    
    // Wait a bit for modal to be visible, then create properly sized container
    setTimeout(() => {
        // Verify bill has content
        if (!billContainer.innerHTML || billContainer.innerHTML.length < 100) {
            alert('Bill content is empty. Please generate the bill first.');
            if (document.body.contains(loadingOverlay)) {
                document.body.removeChild(loadingOverlay);
            }
            return;
        }
        
        // Create a new container sized for A4 (210mm x 297mm)
        // A4 at 96 DPI: 794px width x 1123px height
        const printContainer = document.createElement('div');
        printContainer.className = 'bill-container';
        printContainer.innerHTML = billContainer.innerHTML;
        
        // Set A4 dimensions (210mm = 794px at 96 DPI)
        // A4 page: 210mm x 297mm = 794px x 1123px at 96 DPI
        // Use smaller padding to ensure content fits: 15px padding = 764px content width
        printContainer.style.cssText = `
            position: absolute;
            left: 0;
            top: 0;
            width: 794px;
            min-width: 794px;
            max-width: 794px;
            padding: 15px;
            background: white;
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.5;
            visibility: visible;
            opacity: 1;
            z-index: -9999;
            box-sizing: border-box;
            display: block;
            overflow: hidden;
            margin: 0;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
        `;
        
        // Ensure table and all content fit within the container with clear text rendering
        const style = document.createElement('style');
        style.id = 'printContainerStyle';
        style.textContent = `
            #billContainerPrint {
                width: 794px !important;
                max-width: 794px !important;
                font-size: 12px !important;
                -webkit-font-smoothing: antialiased !important;
                -moz-osx-font-smoothing: grayscale !important;
                text-rendering: optimizeLegibility !important;
            }
            #billContainerPrint .bill-table th,
            #billContainerPrint .bill-table td {
                font-size: 12px !important;
            }
            #billContainerPrint .bill-table {
                width: 100% !important;
                max-width: 100% !important;
                table-layout: fixed !important;
                border-collapse: collapse !important;
            }
            #billContainerPrint .bill-table th,
            #billContainerPrint .bill-table td {
                word-wrap: break-word !important;
                overflow-wrap: break-word !important;
                padding: 6px 4px !important;
                box-sizing: border-box !important;
                -webkit-font-smoothing: antialiased !important;
                -moz-osx-font-smoothing: grayscale !important;
            }
            #billContainerPrint .bill-table th[style*="width"] {
                max-width: 100% !important;
            }
            #billContainerPrint .bill-table .amount-cell {
                padding-right: 12px !important;
                min-width: 72px !important;
                white-space: nowrap !important;
                font-size: 12px !important;
            }
            #billContainerPrint .bill-table .grand-total-row td {
                padding: 8px 12px !important;
                font-size: 13px !important;
                background: #f0f0f0 !important;
            }
            #billContainerPrint .bill-table .grand-total-row .amount-cell {
                font-size: 14px !important;
                font-weight: bold !important;
            }
            #billContainerPrint * {
                max-width: 100% !important;
                box-sizing: border-box !important;
                -webkit-font-smoothing: antialiased !important;
                -moz-osx-font-smoothing: grayscale !important;
            }
            #billContainerPrint h2,
            #billContainerPrint h3,
            #billContainerPrint h4,
            #billContainerPrint p,
            #billContainerPrint span,
            #billContainerPrint strong {
                -webkit-font-smoothing: antialiased !important;
                -moz-osx-font-smoothing: grayscale !important;
                text-rendering: optimizeLegibility !important;
            }
        `;
        document.head.appendChild(style);
        printContainer.id = 'billContainerPrint';
        
        // Append to body temporarily
        document.body.appendChild(printContainer);
        
        // Force reflow to ensure rendering
        const containerHeight = printContainer.scrollHeight || printContainer.offsetHeight;
        const containerWidth = printContainer.offsetWidth || 794;
        
        console.log('Container dimensions:', { width: containerWidth, height: containerHeight });
        
        // PDF options - A4 size, balance of clarity and file size
        // A4: 210mm x 297mm = 794px x 1123px at 96 DPI
        const options = {
            margin: [0, 0, 0, 0], // No margins - padding is already in the container
            filename: fileName,
            image: { type: 'jpeg', quality: 0.98 }, // High quality JPEG for clear text, minimal blur
            html2canvas: { 
                scale: 2.5, // 2.5x scale - sharper text than 2x, reasonable file size
                useCORS: true,
                letterRendering: true,
                backgroundColor: '#ffffff',
                logging: false,
                allowTaint: true,
                width: containerWidth, // Use actual width (should be 794px)
                height: Math.max(containerHeight, 1123), // Use actual height or minimum A4 height
                x: 0,
                y: 0,
                scrollX: 0,
                scrollY: 0,
                windowWidth: containerWidth,
                windowHeight: Math.max(containerHeight, 1123),
                onclone: function(clonedDoc) {
                    // Ensure fonts are properly rendered in the clone
                    const clonedContainer = clonedDoc.querySelector('#billContainerPrint');
                    if (clonedContainer) {
                        // Force font rendering
                        clonedContainer.style.webkitFontSmoothing = 'antialiased';
                        clonedContainer.style.mozOsxFontSmoothing = 'grayscale';
                        clonedContainer.style.textRendering = 'optimizeLegibility';
                        // Ensure all text elements have proper rendering
                        const allElements = clonedContainer.querySelectorAll('*');
                        allElements.forEach(el => {
                            el.style.webkitFontSmoothing = 'antialiased';
                            el.style.mozOsxFontSmoothing = 'grayscale';
                            el.style.textRendering = 'optimizeLegibility';
                        });
                    }
                }
            },
            jsPDF: { 
                unit: 'mm', 
                format: 'a4', 
                orientation: 'portrait',
                compress: true // Enable compression to reduce file size
            },
            pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
        };
        
        // Wait a bit more to ensure everything is rendered
        setTimeout(() => {
            // Generate and download PDF
            html2pdf().set(options).from(printContainer).save().then(() => {
                // Cleanup
                if (document.body.contains(printContainer)) {
                    document.body.removeChild(printContainer);
                }
                if (document.body.contains(loadingOverlay)) {
                    document.body.removeChild(loadingOverlay);
                }
                const styleElement = document.getElementById('printContainerStyle');
                if (styleElement) {
                    document.head.removeChild(styleElement);
                }
                // Restore original modal state if needed
                if (modal && originalModalDisplay === 'none') {
                    modal.style.display = originalModalDisplay;
                }
                showToast('PDF downloaded successfully!', 'success');
            }).catch(err => {
                console.error('PDF generation error:', err);
                console.error('Print container HTML length:', printContainer.innerHTML.length);
                console.error('Print container height:', printContainer.offsetHeight);
                console.error('Print container width:', printContainer.offsetWidth);
                // Cleanup on error
                if (document.body.contains(printContainer)) {
                    document.body.removeChild(printContainer);
                }
                if (document.body.contains(loadingOverlay)) {
                    document.body.removeChild(loadingOverlay);
                }
                const styleElement = document.getElementById('printContainerStyle');
                if (styleElement) {
                    document.head.removeChild(styleElement);
                }
                // Restore original modal state
                if (modal && originalModalDisplay === 'none') {
                    modal.style.display = originalModalDisplay;
                }
                alert('Error generating PDF: ' + (err.message || 'Please try again.'));
            });
        }, 400);
    }, 300);
}

// Download PDF
function downloadPDF() {
    // Generate bill first
    generateBill();
    
    // Wait for bill to be generated
    setTimeout(() => {
        // Get bill container
        const billContainer = document.getElementById('billContainer');
        
        // Check if bill is generated
        if (billContainer.querySelector('.empty-preview')) {
            alert('Please generate the bill first!');
            return;
        }
        
        // Get invoice number and customer name for filename
        const invoiceNo = document.getElementById('invoiceNo').value || 'Invoice';
        const customerName = document.getElementById('customerName').value || 'Customer';
        const fileName = `${invoiceNo}_${customerName.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
        
        // Create a clone of bill container for PDF
        const cloneContainer = document.createElement('div');
        cloneContainer.innerHTML = billContainer.innerHTML;
        cloneContainer.style.cssText = 'width: 210mm; padding: 15mm; background: white; font-family: Arial, sans-serif;';
        
        // Make enterprise name sky blue
        const companyName = cloneContainer.querySelector('.bill-header h2');
        if (companyName) {
            companyName.style.color = '#0ea5e9';
        }
        
        // Append clone to body temporarily (hidden)
        cloneContainer.style.position = 'absolute';
        cloneContainer.style.left = '-9999px';
        cloneContainer.style.top = '0';
        document.body.appendChild(cloneContainer);
        
        // PDF options
        const options = {
            margin: [5, 5, 5, 5],
            filename: fileName,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2,
                useCORS: true,
                letterRendering: true,
                backgroundColor: '#ffffff',
                logging: false
            },
            jsPDF: { 
                unit: 'mm', 
                format: 'a4', 
                orientation: 'portrait',
                compress: true
            }
        };
        
        // Show loading
        const loadingOverlay = document.createElement('div');
        loadingOverlay.id = 'pdfLoading';
        loadingOverlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:9999;';
        loadingOverlay.innerHTML = '<div style="background:white;padding:30px 50px;border-radius:10px;font-size:18px;">Generating PDF... Please wait</div>';
        document.body.appendChild(loadingOverlay);
        
        // Generate PDF
        html2pdf().set(options).from(cloneContainer).save().then(() => {
            // Cleanup
            document.body.removeChild(cloneContainer);
            document.body.removeChild(loadingOverlay);
        }).catch(err => {
            console.error('PDF generation error:', err);
            document.body.removeChild(cloneContainer);
            document.body.removeChild(loadingOverlay);
            alert('Error generating PDF. Please try again.');
        });
    }, 500);
}

// Clear Form
function clearForm() {
    if (!confirm('Are you sure you want to clear all fields?')) return;
    
    document.getElementById('customerSelect').value = '';
    document.getElementById('customerName').value = '';
    document.getElementById('customerAddress').value = '';
    document.getElementById('customerGST').value = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('customerRate').value = '';
    document.getElementById('notes').value = '';
    document.getElementById('discount').value = '0';
    document.getElementById('transportCharges').value = '0';
    
    // Clear items
    document.getElementById('itemsList').innerHTML = '';
    itemCount = 0;
    addItem();
    
    // Generate new invoice number
    generateInvoiceNumber();
    
    // Reset totals
    calculateTotals();
    
    // Clear preview
    document.getElementById('billContainer').innerHTML = `
        <div class="empty-preview">
            <p>Fill in the details and click "Generate Bill" to preview</p>
        </div>
    `;
}

// Show Toast Notification
function showToast(message, type = 'info') {
    // Remove existing toast if any
    const existingToast = document.getElementById('toastNotification');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.id = 'toastNotification';
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 10000;
        font-size: 14px;
        font-weight: 500;
        animation: slideIn 0.3s ease-out;
    `;
    toast.textContent = message;
    
    // Add animation style if not exists
    if (!document.getElementById('toastAnimationStyle')) {
        const style = document.createElement('style');
        style.id = 'toastAnimationStyle';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.style.animation = 'slideIn 0.3s ease-out reverse';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.remove();
                }
            }, 300);
        }
    }, 3000);
}

// Number to Words Conversion
function numberToWords(num) {
    if (num === 0) return 'Zero';
    
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
                  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
                  'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    
    function convertLessThanThousand(n) {
        if (n === 0) return '';
        
        if (n < 20) return ones[n];
        
        if (n < 100) {
            return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + ones[n % 10] : '');
        }
        
        return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 !== 0 ? ' ' + convertLessThanThousand(n % 100) : '');
    }
    
    function convert(n) {
        if (n === 0) return 'Zero';
        
        let result = '';
        
        // Crores (10,000,000)
        if (n >= 10000000) {
            result += convertLessThanThousand(Math.floor(n / 10000000)) + ' Crore ';
            n %= 10000000;
        }
        
        // Lakhs (100,000)
        if (n >= 100000) {
            result += convertLessThanThousand(Math.floor(n / 100000)) + ' Lakh ';
            n %= 100000;
        }
        
        // Thousands
        if (n >= 1000) {
            result += convertLessThanThousand(Math.floor(n / 1000)) + ' Thousand ';
            n %= 1000;
        }
        
        // Hundreds
        if (n >= 100) {
            result += convertLessThanThousand(Math.floor(n / 100)) + ' Hundred ';
            n %= 100;
        }
        
        // Tens and Ones
        if (n > 0) {
            result += convertLessThanThousand(n);
        }
        
        return result.trim();
    }
    
    return convert(Math.abs(Math.round(num)));
}
